How to run program!
install g++ compiler
go to linux terminal and input
g++ -o OSp1 OSp1.cpp
this creates an executable called OSp1

to run OSp1 type:
./OSp1 arg1 arg2 arg3 arg4

where,
arg1 = scheduler decider (1=FCFS, 2=SRTF, 3=HRRN, 4=RR)
arg2 = lambda value
arg3 = average service time
arg4 = quantum value

it will output the results of the program to terminal

Thank you!